package com.chinapay.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import com.chinapay.secss.SecssUtil;
import com.chinapay.util.FormatUtil;
import com.chinapay.util.NetUtil;


public class BatchPayTrade {
	public static final String MERID = "000001904159858";//"000001809125044";
	public static final String VERSION = "20180808";//
	
	public static final String MOBILEFORBANK = "12345678901";
	
	public static final String busiProFlag = "01";
	public static final String relAccountNo = "6222011228881234567";
	public static final String relAccountName = "�Ϻ���������֧��";
	public static final String TERMTYPE = "07";
	public static final String terminalId = "8888888";
	public static final String userId = "test001";
	public static final String userRegisterTime = "20190618153300";
	public static final String userMail = "zhangsan@163.com";
	public static final String userMobile = "18321666789";
	public static final String diskSn = "99999999";
	public static final String mac = "12345678901";
	public static final String imei = "12345678901";
	public static final String ip = "127.0.0.1";
	public static final String wifimac = "12345678901";
	public static final String imsi = "12345678901";
	public static final String iccid = "12345678901";
	public static final String coordinates = "12345678901";
	public static final String baseStationSn = "12345678901";
	public static final String codeInputType = "01";
	public static final String Desc = "��Ʒ��Ϣ";
	
	
	public static final String url = "https://sfj-test.chinapay.com/dac/BatchPayTrade";

	public static void main(String[] args) throws Exception {
		
		SimpleDateFormat sf1 = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sf2 = new SimpleDateFormat("HHmmss");
		Date dt = new Date();

		String MerSeqId = sf2.format(dt); // ���κ�
		String TransDate = sf1.format(dt); // ��������
		String fileName = MERID+"_"+TransDate+"_"+MerSeqId+".txt";

		String fileContent = MERID + "|" + MerSeqId + "|"+3+"|3000";
		System.out.println("�ļ�ͷ��" + fileContent);
		fileContent += "\r\n"
			+ TransDate
			+ "|"
			+ TransDate + MerSeqId+1
			+ "|6228481190350963516|����1|CNY|1000|��������|�ֶ�֧��||�Ϻ�|�Ϻ�|00|����1|{\"test\":\"����\"}|1||||07|||||||||||||||||";
		fileContent += "\r\n"
			+ TransDate
			+ "|"
			+ TransDate + MerSeqId + 2
			+ "|6228481190350963516|����2|CNY|1000|��������|�ֶ�֧��||�Ϻ�|�Ϻ�|00|����1|{\"test\":\"����\"}|1||||07|||||||||||||||||";
		fileContent += "\r\n"
			+ TransDate
			+ "|"
			+ TransDate + MerSeqId + 3
			+ "|6228481190350963516|����3|CNY|1000|��������|�ֶ�֧��||�Ϻ�|�Ϻ�|00|����1|{\"test\":\"����\"}|1||||07|||||||||||||||||";

		
		System.out.println(fileContent);
		
		SecssUtil secssUtil = new SecssUtil();
		boolean b = secssUtil.init();
		String contentStr = secssUtil.encodeEnvelope(fileContent.getBytes("GBK"));
		
		Map<String,String> signMap = new HashMap<String,String>();
		signMap.put("merId", MERID);
		signMap.put("fileContent", contentStr);
		signMap.put("version", VERSION);
		signMap.put("fileName", fileName);
		secssUtil.sign(signMap);
		String chkValue = secssUtil.getSign();
		signMap.put("chkValue", chkValue);
		
		try {
			String data = JSONObject.fromObject(signMap).toString();
			String result = NetUtil.sendJson(url, data, "GBK");
			System.out.println("��������" + "[" + result + "]");

			Map<String, String> retMap = (Map<String, String>)JSONObject.fromObject(result);
			secssUtil.verify(retMap);
			String errorCode = secssUtil.getErrCode();
			
			if (!"00".equals(errorCode)) {
				System.out.println("��ǩʧ��");
			} else {
				System.out.println("��ǩ�ɹ�");
			}
			
			System.out.println("responseCode=" + retMap.get("responseCode"));
			System.out.println("responseMsg="+FormatUtil.Unicode2GBK(retMap.get("responseMsg")));
			System.out.println("msgCode=" + retMap.get("msgCode"));
			System.out.println("msgDesc="+FormatUtil.Unicode2GBK(retMap.get("msgDesc")));
			
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			
		}
	}
}
