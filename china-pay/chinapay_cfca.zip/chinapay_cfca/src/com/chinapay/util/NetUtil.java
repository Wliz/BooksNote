package com.chinapay.util;

import java.io.IOException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;


/**  
 * ClassName: NetUtil <br/>  
 * Function:  ADD FUNCTION. <br/>  
 * date: 2017-6-8 ����2:44:20 <br/>  
 *  
 * @author dell  
 * @version   
 */
public class NetUtil {
	/**  
	 * logger:(��һ�仰�������������ʾʲô).   
	 */
	private static final Logger logger = Logger.getLogger(NetUtil.class);
	
	public static String sendJson(String url, String reqContent,String charset) throws Exception{
		String result = "";
		// �ַ�������
		if (StringUtils.isBlank(charset)) {
			charset = "GBK";
		}

		// ����http POST����
		CloseableHttpClient httpclient = null;  
		HttpPost httpPost = new HttpPost(url);
	
		CloseableHttpResponse response = null;

		try {
			httpPost.setHeader(HttpHeaders.CONTENT_ENCODING, charset);
		    httpPost.setHeader(HttpHeaders.CONTENT_TYPE, "application/json;charset="+charset);
			
			// ���ò���
			Builder customReqConf = RequestConfig.custom();
			customReqConf.setConnectTimeout(10000);
			customReqConf.setConnectTimeout(60000);
			
			StringEntity reqEntity = new StringEntity(reqContent,charset);
			httpPost.setEntity(reqEntity);
			if (url.startsWith("https")) {
				SSLContext context = buildSSLContext();
				// ִ��Https����
				httpclient = HttpClientBuilder.create().setDefaultRequestConfig(customReqConf.build())
						.setHostnameVerifier(new AllowAllHostnameVerifier())
						.setSslcontext(context).build();
			} else {
				httpclient = HttpClientBuilder.create().setDefaultRequestConfig(customReqConf.build()).build();
			}
			
			response = httpclient.execute(httpPost);
			
			 if (response != null) {
				 logger.info("����״̬��:"+response.getStatusLine().getStatusCode());
					// �жϷ���״̬�Ƿ�Ϊ200
					if (response.getStatusLine().getStatusCode() == 200) {
						result = EntityUtils.toString(response.getEntity(),charset);
					}
			 }else{
				 logger.info("�����޽��");
			 }
			
		} catch (Exception e) {
			logger.error("����ʧ��", e);
			throw e;
		} finally {
			if(response != null) {
				try {
					response.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			if(httpclient != null) {
				httpclient.close();
			}
		}
		
		return result;
	}
	
	/**
	 * ����SSL������.
	 *
	 * @return  SSLContext
	 * @author cp
	 */
	private static SSLContext buildSSLContext() {
		try {
			SSLContext sslc = SSLContext.getInstance("TLS");
			sslc.init(null, createNonValidateTrustmanager(), null);
			
			return sslc;
		} catch (Exception ex) {
			logger.error("SSL�����Ĵ���ʧ�ܣ�����ϵ����Ա.", ex);
		}
		return null;
	}
	
	/**
	 * ����һ��֤��.
	 *
	 * @return  TrustManager[]
	 * @author cp
	 */
	private static TrustManager[] createNonValidateTrustmanager() {
        TrustManager[] trustAllCerts = new TrustManager[]{
            new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }};
        return trustAllCerts;
	}
	
}
